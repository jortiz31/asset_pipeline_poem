// app/assets/javascripts/application.js

// require roses_are_red
// require violets_are_blue
// require compile_your_assets
// require then_hit_opt_cmd_u
